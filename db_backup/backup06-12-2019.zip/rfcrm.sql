#
# TABLE STRUCTURE FOR: alerta
#

DROP TABLE IF EXISTS `alerta`;

CREATE TABLE `alerta` (
  `alerta_id` int(11) NOT NULL AUTO_INCREMENT,
  `alerta_titulo` varchar(50) NOT NULL,
  `alerta_mensagem` varchar(1000) NOT NULL,
  `alerta_usuario` varchar(50) NOT NULL,
  `alerta_data` varchar(20) NOT NULL,
  PRIMARY KEY (`alerta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `alerta` (`alerta_id`, `alerta_titulo`, `alerta_mensagem`, `alerta_usuario`, `alerta_data`) VALUES (10, 'teste', 'teste', 'Johann Kaltner', '05-12-2019 16:49');
INSERT INTO `alerta` (`alerta_id`, `alerta_titulo`, `alerta_mensagem`, `alerta_usuario`, `alerta_data`) VALUES (11, 'teste2', 'tste2', 'Johann Kaltner', '05-12-2019 16:51');
INSERT INTO `alerta` (`alerta_id`, `alerta_titulo`, `alerta_mensagem`, `alerta_usuario`, `alerta_data`) VALUES (12, 'teste3', 'teste3', 'Johann Kaltner', '05-12-2019 16:51');
INSERT INTO `alerta` (`alerta_id`, `alerta_titulo`, `alerta_mensagem`, `alerta_usuario`, `alerta_data`) VALUES (13, 'teste4', 'teste4', 'Johann Kaltner', '05-12-2019 16:51');


#
# TABLE STRUCTURE FOR: chamado
#

DROP TABLE IF EXISTS `chamado`;

CREATE TABLE `chamado` (
  `chamado_id` int(11) NOT NULL AUTO_INCREMENT,
  `chamado_id_cliente` int(50) NOT NULL,
  `chamado_id_usuario` int(11) NOT NULL,
  `chamado_atividade` varchar(50) NOT NULL,
  `chamado_duracao_hora` varchar(50) DEFAULT NULL,
  `chamado_assunto` varchar(50) NOT NULL,
  `chamado_data` varchar(50) NOT NULL,
  `chamado_hora` varchar(50) DEFAULT NULL,
  `chamado_duracao_minuto` varchar(50) DEFAULT NULL,
  `chamado_atendente_rf` varchar(50) NOT NULL,
  `chamado_atendente_cliente` varchar(50) NOT NULL,
  `chamado_telefone` int(20) DEFAULT NULL,
  `chamado_email` varchar(50) DEFAULT NULL,
  `chamado_obs` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`chamado_id`),
  KEY `chamado_id_cliente` (`chamado_id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (6, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (8, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (9, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (10, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (11, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (12, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (13, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (14, 0, 5, 'Tirar duvida(s)', '1', 'TESTE', '05/12/2019', '11:39:36', '2', 'Johann Kaltner', 'fulano', 2147483647, 'teste@teste', 'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (15, 0, 5, 'Tirar duvida(s)', '1', 'teste', '05/12/2019', '15:12:09', '444', 'Johann Kaltner', 'Fulano', 0, 'delete@delete', 'cardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcardcard');
INSERT INTO `chamado` (`chamado_id`, `chamado_id_cliente`, `chamado_id_usuario`, `chamado_atividade`, `chamado_duracao_hora`, `chamado_assunto`, `chamado_data`, `chamado_hora`, `chamado_duracao_minuto`, `chamado_atendente_rf`, `chamado_atendente_cliente`, `chamado_telefone`, `chamado_email`, `chamado_obs`) VALUES (16, 30, 5, 'Tirar duvida(s)', '1', 'teste30', '05/12/2019', '16:52:31', '3', 'Johann Kaltner', 'teste', 0, 'teste@teste', 'teste 1');


#
# TABLE STRUCTURE FOR: chamado_old
#

DROP TABLE IF EXISTS `chamado_old`;

CREATE TABLE `chamado_old` (
  `chamado_id` int(11) NOT NULL AUTO_INCREMENT,
  `chamado_id_cliente` int(50) NOT NULL,
  `chamado_atividade` varchar(50) NOT NULL,
  `chamado_duracao_hora` varchar(50) DEFAULT NULL,
  `chamado_assunto` varchar(50) NOT NULL,
  `chamado_data` varchar(50) NOT NULL,
  `chamado_hora` varchar(50) DEFAULT NULL,
  `chamado_duracao_minuto` varchar(50) DEFAULT NULL,
  `chamado_atendente_rf` varchar(50) NOT NULL,
  `chamado_atendente_cliente` varchar(50) NOT NULL,
  `chamado_telefone` int(20) DEFAULT NULL,
  `chamado_email` varchar(50) DEFAULT NULL,
  `chamado_obs` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`chamado_id`),
  KEY `chamado_id_cliente` (`chamado_id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cliente
#

DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_contato_id` int(11) NOT NULL,
  `cliente_id_usuario` int(11) NOT NULL,
  `cod_cliente` int(10) DEFAULT NULL,
  `cliente_nome` varchar(50) NOT NULL,
  `cliente_endereco` varchar(50) NOT NULL,
  `cliente_bairro` varchar(50) NOT NULL,
  `cliente_cidade` varchar(50) NOT NULL,
  `cliente_estado` varchar(50) NOT NULL,
  `cliente_pais` varchar(50) DEFAULT NULL,
  `cliente_cep` varchar(50) NOT NULL,
  `cliente_cpf` varchar(50) DEFAULT NULL,
  `cliente_cnpj` varchar(20) DEFAULT NULL,
  `cliente_inscricao_estadual` varchar(50) NOT NULL,
  `cliente_categoria` varchar(50) DEFAULT NULL,
  `cliente_email` varchar(50) NOT NULL,
  `cliente_telefone` varchar(50) NOT NULL,
  `cliente_regiao` varchar(50) NOT NULL,
  `cliente_obs` varchar(500) NOT NULL,
  `cliente_img` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`cliente_id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `cliente_contato_id` (`cliente_contato_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `cliente` (`cliente_id`, `cliente_contato_id`, `cliente_id_usuario`, `cod_cliente`, `cliente_nome`, `cliente_endereco`, `cliente_bairro`, `cliente_cidade`, `cliente_estado`, `cliente_pais`, `cliente_cep`, `cliente_cpf`, `cliente_cnpj`, `cliente_inscricao_estadual`, `cliente_categoria`, `cliente_email`, `cliente_telefone`, `cliente_regiao`, `cliente_obs`, `cliente_img`) VALUES (0, 0, 0, 4, 'Johann Kaltner', 'Estrada do Gabinal 313', 'Freguesia ', 'Rio de Janeiro', '', 'Brasil', '12312-312', '123.123.123-12', '', '123.123.123.123', 'Desenvolvedor', 'jkdoliveira@gmail.com', '', '', '', NULL);
INSERT INTO `cliente` (`cliente_id`, `cliente_contato_id`, `cliente_id_usuario`, `cod_cliente`, `cliente_nome`, `cliente_endereco`, `cliente_bairro`, `cliente_cidade`, `cliente_estado`, `cliente_pais`, `cliente_cep`, `cliente_cpf`, `cliente_cnpj`, `cliente_inscricao_estadual`, `cliente_categoria`, `cliente_email`, `cliente_telefone`, `cliente_regiao`, `cliente_obs`, `cliente_img`) VALUES (30, 0, 5, 0, 'TESTE', 'TESTE', 'TESTE', 'TESTE', 'TESTE', 'TESTE', '46956-465', '231.231.231-23', '12.312.312/3123-12', '654.545.454.646', 'ASS.EMPRES./JURÍDICO', 'TESTE@TESTE', '(65) 46546-5465', '', '', NULL);
INSERT INTO `cliente` (`cliente_id`, `cliente_contato_id`, `cliente_id_usuario`, `cod_cliente`, `cliente_nome`, `cliente_endereco`, `cliente_bairro`, `cliente_cidade`, `cliente_estado`, `cliente_pais`, `cliente_cep`, `cliente_cpf`, `cliente_cnpj`, `cliente_inscricao_estadual`, `cliente_categoria`, `cliente_email`, `cliente_telefone`, `cliente_regiao`, `cliente_obs`, `cliente_img`) VALUES (31, 0, 5, 0, '', '', '', '', '', '', '', '', '', '', 'Não Selecionado...', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: cliente_old
#

DROP TABLE IF EXISTS `cliente_old`;

CREATE TABLE `cliente_old` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_nome` varchar(50) NOT NULL,
  `cliente_endereco` varchar(50) NOT NULL,
  `cliente_bairro` varchar(50) NOT NULL,
  `cliente_cidade` varchar(50) NOT NULL,
  `cliente_estado` varchar(50) NOT NULL,
  `cliente_pais` varchar(50) DEFAULT NULL,
  `cliente_cep` varchar(50) NOT NULL,
  `cliente_cnpj_cpf` varchar(50) NOT NULL,
  `cliente_inscricao_estadual` varchar(50) NOT NULL,
  `cliente_categoria` varchar(50) DEFAULT NULL,
  `cliente_email` varchar(50) NOT NULL,
  `cliente_telefone` varchar(50) NOT NULL,
  `cliente_regiao` varchar(50) NOT NULL,
  `cliente_obs` varchar(50) NOT NULL,
  `cliente_contato_nome` varchar(50) DEFAULT NULL,
  `cliente_contato_telefone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cliente_id`),
  KEY `cliente_id` (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: contato_secundario
#

DROP TABLE IF EXISTS `contato_secundario`;

CREATE TABLE `contato_secundario` (
  `contato_secundario_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_contato_id` int(11) DEFAULT NULL,
  `contato_id_usuario` int(11) DEFAULT NULL,
  `contato_secundario_nome` varchar(200) DEFAULT NULL,
  `contato_secundario_email` varchar(200) DEFAULT NULL,
  `contato_secundario_telefone` int(11) DEFAULT NULL,
  `contato_secundario_funcao` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`contato_secundario_id`),
  KEY `contato_secundario_id_cliente` (`cliente_contato_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `contato_secundario` (`contato_secundario_id`, `cliente_contato_id`, `contato_id_usuario`, `contato_secundario_nome`, `contato_secundario_email`, `contato_secundario_telefone`, `contato_secundario_funcao`) VALUES (33, 0, 5, '12312312', '3123123123!@123123', 0, '23123213');
INSERT INTO `contato_secundario` (`contato_secundario_id`, `cliente_contato_id`, `contato_id_usuario`, `contato_secundario_nome`, `contato_secundario_email`, `contato_secundario_telefone`, `contato_secundario_funcao`) VALUES (34, 31, 5, '', '', 0, '');
INSERT INTO `contato_secundario` (`contato_secundario_id`, `cliente_contato_id`, `contato_id_usuario`, `contato_secundario_nome`, `contato_secundario_email`, `contato_secundario_telefone`, `contato_secundario_funcao`) VALUES (35, 0, 5, 'Fulano', 'fulano@teste', 0, 'Gerente');
INSERT INTO `contato_secundario` (`contato_secundario_id`, `cliente_contato_id`, `contato_id_usuario`, `contato_secundario_nome`, `contato_secundario_email`, `contato_secundario_telefone`, `contato_secundario_funcao`) VALUES (36, 30, 5, 'teste', 'teste@tweasd', 0, 'tester');


#
# TABLE STRUCTURE FOR: correcao
#

DROP TABLE IF EXISTS `correcao`;

CREATE TABLE `correcao` (
  `correcao_id` int(11) NOT NULL AUTO_INCREMENT,
  `correcao_id_cliente` int(50) NOT NULL,
  `correcao_usuario_id` int(11) DEFAULT NULL,
  `correcao_id_chamado` int(11) NOT NULL,
  `correcao_atividade` varchar(50) NOT NULL,
  `correcao_duracao_hora` varchar(50) DEFAULT NULL,
  `correcao_assunto` varchar(50) NOT NULL,
  `correcao_data` varchar(50) NOT NULL,
  `correcao_hora` varchar(50) DEFAULT NULL,
  `correcao_duracao_minuto` varchar(50) DEFAULT NULL,
  `correcao_atendente_rf` varchar(50) NOT NULL,
  `correcao_atendente_cliente` varchar(50) NOT NULL,
  `correcao_telefone` int(20) DEFAULT NULL,
  `correcao_email` varchar(50) DEFAULT NULL,
  `correcao_obs` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`correcao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `correcao` (`correcao_id`, `correcao_id_cliente`, `correcao_usuario_id`, `correcao_id_chamado`, `correcao_atividade`, `correcao_duracao_hora`, `correcao_assunto`, `correcao_data`, `correcao_hora`, `correcao_duracao_minuto`, `correcao_atendente_rf`, `correcao_atendente_cliente`, `correcao_telefone`, `correcao_email`, `correcao_obs`) VALUES (11, 0, 5, 1, 'primeiro chamado', '1', 'teste', '19/11/2019', '12:12:41', '10', 'nnahoj', 'johann', 0, NULL, 'teste');
INSERT INTO `correcao` (`correcao_id`, `correcao_id_cliente`, `correcao_usuario_id`, `correcao_id_chamado`, `correcao_atividade`, `correcao_duracao_hora`, `correcao_assunto`, `correcao_data`, `correcao_hora`, `correcao_duracao_minuto`, `correcao_atendente_rf`, `correcao_atendente_cliente`, `correcao_telefone`, `correcao_email`, `correcao_obs`) VALUES (12, 0, 5, 1, '', '', '', '27/11/2019', '12:59:00', '', 'Alexandre Furtado', '', 0, NULL, '');
INSERT INTO `correcao` (`correcao_id`, `correcao_id_cliente`, `correcao_usuario_id`, `correcao_id_chamado`, `correcao_atividade`, `correcao_duracao_hora`, `correcao_assunto`, `correcao_data`, `correcao_hora`, `correcao_duracao_minuto`, `correcao_atendente_rf`, `correcao_atendente_cliente`, `correcao_telefone`, `correcao_email`, `correcao_obs`) VALUES (13, 30, NULL, 16, '', '', '', '05/12/2019', '16:54:52', '', 'Johann Kaltner', '', 0, NULL, '');


#
# TABLE STRUCTURE FOR: log
#

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_atividade` varchar(200) NOT NULL,
  `log_tipo` varchar(10) NOT NULL,
  `log_data` varchar(50) NOT NULL,
  `log_usuario_nome` varchar(50) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (1, 'Registrou  um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (2, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (3, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (4, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (5, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (6, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (7, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (8, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (9, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (10, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (11, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (12, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (13, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (14, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (15, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (16, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (17, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (18, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (19, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (20, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (21, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (22, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (23, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (24, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (25, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (26, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (27, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (28, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (29, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (30, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (31, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (32, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (33, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (34, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (35, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (36, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (37, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (38, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (39, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (40, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (41, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (42, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (43, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (44, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (45, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (46, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (47, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (48, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (49, 'Registrou um cliente com id = 15 ', '1', '10/08/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (50, 'teste', '2', '08/10/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (51, 'teste3', '3', '11/11/2000 - 12:00', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (52, 'testou', '3', '06/12/2020', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (53, 'testou', '3', '06/12/2021', 'Johann Kaltner');
INSERT INTO `log` (`log_id`, `log_atividade`, `log_tipo`, `log_data`, `log_usuario_nome`) VALUES (54, 'testou', '3', '07/12/2021', 'Johann Kaltner');


#
# TABLE STRUCTURE FOR: usuario
#

DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_nome` varchar(100) NOT NULL,
  `usuario_email` varchar(50) NOT NULL,
  `usuario_senha` varchar(50) NOT NULL,
  `usuario_setor` varchar(50) NOT NULL,
  `usuario_nivel` int(11) NOT NULL,
  `usuario_data_inicio` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO `usuario` (`usuario_id`, `usuario_nome`, `usuario_email`, `usuario_senha`, `usuario_setor`, `usuario_nivel`, `usuario_data_inicio`) VALUES (5, 'Johann Kaltner', 'johann@rfcrm.com', '1234', 'Comercial', 1, '09/10/2019');
INSERT INTO `usuario` (`usuario_id`, `usuario_nome`, `usuario_email`, `usuario_senha`, `usuario_setor`, `usuario_nivel`, `usuario_data_inicio`) VALUES (8, 'Beth ', 'beth@rfcrm.com', '1234', 'Comercial', 0, NULL);
INSERT INTO `usuario` (`usuario_id`, `usuario_nome`, `usuario_email`, `usuario_senha`, `usuario_setor`, `usuario_nivel`, `usuario_data_inicio`) VALUES (13, 'Alexandre Furtado', 'alexandrefurtado@rfcrm.com', '1234', 'Administração', 1, NULL);


